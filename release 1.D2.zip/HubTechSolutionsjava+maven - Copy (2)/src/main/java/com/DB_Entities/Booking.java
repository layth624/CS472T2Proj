package com.DB_Entities;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class Booking {
    private int bookingId;
    private int reservationId;
    private double totalCost;
    private String creditCardNumber;
    private Date bookingDate;

    public Booking(int bookingId, int reservationId, double totalCost, String creditCardNumber, Date bookingDate) {
        this.bookingId = bookingId;
        this.reservationId = reservationId;
        this.totalCost = totalCost;
        this.creditCardNumber = creditCardNumber;
        this.bookingDate = bookingDate;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }

    @Override
    public String toString() {
        return "Booking{" +
                "bookingId=" + bookingId +
                ", reservationId=" + reservationId +
                ", totalCost=" + totalCost +
                ", creditCardNumber='" + creditCardNumber + '\'' +
                ", bookingDate=" + bookingDate +
                '}';
    }

    public static void createBooking(Booking booking) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = DatabaseConnector.getConnection();
            String query = "INSERT INTO bookings (reservation_id, total_cost, credit_card_number, booking_date) VALUES (?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            preparedStatement.setInt(1, booking.getReservationId());
            preparedStatement.setDouble(2, booking.getTotalCost());
            preparedStatement.setString(3, booking.getCreditCardNumber());
            preparedStatement.setDate(4, new java.sql.Date(booking.getBookingDate().getTime()));
            preparedStatement.executeUpdate();

            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int bookingId = generatedKeys.getInt(1);
                // Store the generated booking ID if needed
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                DatabaseConnector.closeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}