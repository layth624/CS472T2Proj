import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        // Add other parameters here
        
        try {
            Connection con = Database.getConnection(); // Use your Database Connector class here
            String query = "INSERT INTO users (Name, Username, Email) VALUES (?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, username);
            pstmt.setString(3, email);
            // Add other fields to the query and set their values
            int result = pstmt.executeUpdate();
            if (result > 0) {
                // Registration successful
                response.sendRedirect("registrationSuccess.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}